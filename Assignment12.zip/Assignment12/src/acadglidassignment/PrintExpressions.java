package acadglidassignment;

import java.io.IOException;
import java.util.Scanner;

public class PrintExpressions {
	public static void main(String[] args) throws IOException {
		try {
			Scanner objScanner = new Scanner(System.in);
			System.out.println("\n Please enter value of a");
			int numA = objScanner.nextInt();
			System.out.println("\n Please enter value of b");
			int numB = objScanner.nextInt();
			System.out.println("\n result of b= a-- - --a is " + (numA-- - --numA));
			System.out.println("\n result of c=a-- is " + (numA--));
			System.out.println("\n result of d=a>>2 is " + (numA >> 2));
			System.out.println("\n result of e=a&b is " + (numA & numB));
			objScanner.close();
		} catch (java.util.InputMismatchException ex) {
			System.out.println("Please enter a valid input");
		}
	}
}
